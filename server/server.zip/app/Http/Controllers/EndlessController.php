<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Endless;
use Auth;

class EndlessController extends Controller
{
    public function leaderboard()
    {
    	$endless = Endless::all();
    	return response()->json($endless);
    }

    public function store(Request $request)
    {
        $endless = new Endless;
        if (Auth::check()) {
            $endless->username = Auth::user()->username;
        }else {
            $endless->username = 'guest';
        }
        $endless->score = 10;
    	if ($endless) {
            $endless->save();
    		return response()->json(['status' => 'success', 'message' => 'Score has been store' ],201);
    	}
    	else {
    		return response()->json(['status' => 'error', 'message' => 'Internal Server Error'],500);
    	}
    }
}
