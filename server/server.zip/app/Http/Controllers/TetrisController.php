<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Tetris;
use Auth;

class TetrisController extends Controller
{
    public function leaderboard()
    {
    	$tetris = Tetris::all();
    	return response()->json($tetris);
    }

    public function store(Request $request)
    {
        $tetris = new Tetris;
        if (Auth::check()) {
            $tetris->username = Auth::user()->username;
        }else {
            $tetris->username = 'guest';
        }
        $tetris->score = 10;
    	if ($tetris) {
            $tetris->save();
    		return response()->json(['status' => 'success', 'message' => 'Score has been store' ],201);
    	}
    	else {
    		return response()->json(['status' => 'error', 'message' => 'Internal Server Error'],500);
    	}
    }
}
