<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;

class APIController extends Controller
{
    function index()
    {
    	$user = User::all();
    	return response()->json($user);
    }
}
