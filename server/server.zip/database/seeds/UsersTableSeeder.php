<?php

use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \App\User::insert([

        	[
        		'name' =>  'Jhon Doe',
        		'username' => 'jhondoe',
        		'email' => 'jhon@gmail.com',
        		'password' => bcrypt('jhondoe123'),
        		'date' => '1992-01-01',
        		'phone' => '0897923420',
        		'picture' => 'jhon.jpg',
        		'api_token' => str_random(60),

        	],
        	[
        		'name' =>  'Iliana',
        		'username' => 'iliana',
        		'email' => 'iliana@gmail.com',
        		'password' => bcrypt('iliana123'),
        		'date' => '1992-02-01',
        		'phone' => '0898123420',
        		'picture' => 'iliana.jpg',
        		'api_token' => str_random(60),     	
        	],
        	[
        		'name' =>  'Sumanto Inrul',
        		'username' => 'sumanto',
        		'email' => 'sumanto@gmail.com',
        		'password' => bcrypt('sumanto123'),
        		'date' => '1992-02-02',
        		'phone' => '0778129909',
        		'picture' => 'sumanto.jpg',
        		'api_token' => str_random(60),     	
        	],


        ]);
    }
}
