<?php

use Illuminate\Database\Seeder;

class GamesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \App\Tetris::insert([
        	[
        		'username' => 'jhondoe',
        		'score' => 20,
        	],
        	[
        		'username' => 'iliana',
        		'score' => 30,
        	],
        	[
        		'username' => 'sumanto',
        		'score' => 25,
        	],
        ]);
        \App\Endless::insert([
        	[
        		'username' => 'jhondoe',
        		'score' => 25,
        	],
        	[
        		'username' => 'iliana',
        		'score' => 35,
        	],
        	[
        		'username' => 'sumanto',
        		'score' => 65,
        	],
        ]);
    }
}
